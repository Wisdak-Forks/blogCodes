
Thanks for purchasing Lantro UI!

<!--[ Paid ]-->

Lantro UI paid by nldblog.com

<!--[ About Lantro UI ]-->

* Lantro UI is fully optimized Blogger template with many that you might be like. 
* You can use this thme for Blog in any category.
* Lantro UI load's faster for better user experiance.

<!--[ After payment ]-->

* Don't worry about next version, you only want to pay onetime then you get free updates forever.

<!--[ Note ]-->

* You must not distribute/resell this theme, If you do so, you will not get the updates.

<!--[ Support ]-->

* We give you 15 days support that includes customization, bug fixes etc.


Thanks for Reading!
