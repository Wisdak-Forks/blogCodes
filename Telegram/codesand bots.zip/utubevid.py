#pip install pycopy-webbrowser

import webbrowser
url = input("Enter the url of youtube video : ")
download = url[:12]+"ss"+url[12:]
webbrowser.open(download)
