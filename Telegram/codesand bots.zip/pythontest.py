from tkinter import * 

root=Tk()
root.title("Python Test")
root.geometry("400x400")
#root.resizable(0,0)

# Create a label
label=Label(root, text="Hello World", font=("Arial", 20))
label.pack()

# Create a second label with a different font
label2=Label(root, text="Hello World", font=("Times", 20))
label2.pack()

# Create a second label with a different font
label3=Label(root, text="Hello World", font=("Courier", 20))
label3.pack()

# Create a second label with a different font
label4=Label(root, text="Hello World", font=("Helvetica", 20))
label4.pack()

# Create a second label with a different font
label5=Label(root, text="Hello World", font=("Verdana", 20))
root.mainloop()

