result = "hello"
print(result)

import platform  as pf

x = pf.system()
print(x)

import platform

x = dir(platform)
print(x)