#pip install pyautogui

import pyautogui,time

while True:
    pyautogui.moveRel(0, 8)
    time.sleep(1)