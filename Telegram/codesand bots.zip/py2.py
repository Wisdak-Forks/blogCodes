import requests as r

x = r.get('https://itsapp.uew.edu.gh:445/pls/prodi41/w99pkg.mi_main_menu')

print(x)