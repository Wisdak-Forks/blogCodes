#message_to_contacts(msg, contacts, gechodriver, gechodriver_log, user_profile, image)
from datetime import datetime
import autowhatspy
import os
import time
path = os.path.dirname(os.path.realpath(__file__)) + "\\"
msg = path + "msg.txt"
contacts = path + "contacts.txt"
gechodriver = path + "gechodriver.exe"
gechodriver_log = path + "gecholog.txt"
user_profile = path + "firefoxprofile"
while True:
    now = datetime.now()
    current_time = now.strftime("%H%M")
    if current_time == "2315":
        autowhatspy.message_to_contacts(msg, contacts, gechodriver, gechodriver_log, user_profile)
        time.sleep(60)
    else:
        time.sleep(30)