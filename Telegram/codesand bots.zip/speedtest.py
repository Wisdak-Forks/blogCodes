# pip install pyspeedtest
# pip install speedtest
# pip install speedtest-cli
#method 1
import speedtest
SpeedTest = speedtest.Speedtest() 
print(speedTest.get_best_server())
#Check download speed
print(SpeedTest.download())
#Check upload speed
print(SpeedTest.upload())
# Method 2
import pyspeedtest
st = pyspeedtest.SpeedTest()
st.ping()
st.download()
st.upload()
